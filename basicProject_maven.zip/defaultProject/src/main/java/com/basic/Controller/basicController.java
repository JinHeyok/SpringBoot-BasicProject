package com.basic.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.basic.DAO.basicDAO;

@Controller
public class basicController {

	@Autowired
	basicDAO basicDAO;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String connection(){
		
		try {
			
			int connectionStatus = basicDAO.connection();
			
			System.out.println(connectionStatus);
			
			if(connectionStatus == 1) {
				System.out.println("DB Connection SUCCESS");
			}
			
		} catch (Exception e) {
			System.out.println("ERROR");
			System.out.println(e);
			System.out.println("DB Connection FAIL");
		}
		
		return "index";
	}
	
}
