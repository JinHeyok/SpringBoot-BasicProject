package com.basic.DAO;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface basicDAO {
		
	int connection();
	
}
