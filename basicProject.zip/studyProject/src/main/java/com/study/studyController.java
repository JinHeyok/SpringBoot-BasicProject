package com.study;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.study.DTO.empDTO;
import com.study.Mapper.empMapper;


@Controller
public class studyController {
	
	@Autowired
	empMapper mapper;
	
	@RequestMapping(value="/" , method = RequestMethod.GET)
	public String home() {
			System.out.println("home");
		return "redirect:connection";
	}
	
	@RequestMapping(value="/connection" , method = RequestMethod.GET)
	public String connection() {
		
		List<empDTO> list = mapper.getEmpList();
		System.out.println(list);
		return "index";
	}
		
}
