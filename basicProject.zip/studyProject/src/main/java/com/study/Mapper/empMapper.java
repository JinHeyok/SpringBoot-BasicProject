package com.study.Mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.study.DTO.empDTO;

@Mapper
@Repository
public interface empMapper {
	List<empDTO> getEmpList();
}
