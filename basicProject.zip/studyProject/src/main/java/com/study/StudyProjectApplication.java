package com.study;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudyProjectApplication {

	public static void main(String[] args) {
		System.out.println("최초 main 실행");
		SpringApplication.run(StudyProjectApplication.class, args);
	}

}
