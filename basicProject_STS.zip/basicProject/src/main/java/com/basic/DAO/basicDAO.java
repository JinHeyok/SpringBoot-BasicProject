package com.basic.DAO;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class basicDAO {

	@Autowired
	SqlSession session;
	
	//연결 테스트 
	public int connection() {
		return session.selectOne("connection");
	}
	
	
}
