package com.basic.DTO;

import org.apache.ibatis.type.Alias;

@Alias("basicDTO")
public class basicDTO {

	private int empno;
	private String ename;
	private String job;
	private int mgr;
	private String date;
	private int sal;
	private int comm;
	private int depteno;

	public basicDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public basicDTO(int empno, String ename, String job, int mgr, String date, int sal, int comm, int depteno) {
		super();
		this.empno = empno;
		this.ename = ename;
		this.job = job;
		this.mgr = mgr;
		this.date = date;
		this.sal = sal;
		this.comm = comm;
		this.depteno = depteno;
	}

	@Override
	public String toString() {
		return "basicDTO [empno=" + empno + ", ename=" + ename + ", job=" + job + ", mgr=" + mgr + ", date=" + date
				+ ", sal=" + sal + ", comm=" + comm + ", depteno=" + depteno + "]";
	}

	public int getEmpno() {
		return empno;
	}

	public void setEmpno(int empno) {
		this.empno = empno;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public int getMgr() {
		return mgr;
	}

	public void setMgr(int mgr) {
		this.mgr = mgr;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public int getSal() {
		return sal;
	}

	public void setSal(int sal) {
		this.sal = sal;
	}

	public int getComm() {
		return comm;
	}

	public void setComm(int comm) {
		this.comm = comm;
	}

	public int getDepteno() {
		return depteno;
	}

	public void setDepteno(int depteno) {
		this.depteno = depteno;
	}

}
