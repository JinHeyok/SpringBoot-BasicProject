package com.basic.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.basic.Mapper.basicMapper;

@Controller
public class basicController {
	
	@Autowired
	basicMapper basicMapper;

	@RequestMapping(value="/" , method = RequestMethod.GET)
	public String connection() {
		
		try {
			int connectionStatus = basicMapper.connection();
			
			if(connectionStatus == 1) {
				System.out.println("DB Connection SUCCESS");
			}
			
		} catch (Exception e) {
			System.out.println("ERROR");
			System.out.println(e);
			System.out.println("DB Connection FAIL");
		}
		
		return "index";
	}
	
}
